#!/bin/bash

# file having the log-data
input_file="access.log"

grep 'POST' "$input_file" | grep ' 404 ' > temp_file.log
cat temp_file.log
rm temp_file.log

