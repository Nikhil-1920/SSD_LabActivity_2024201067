[Ques.01. Log Entry Formatting]
This task involves formatting log entries to match a specified output format.

[Steps for executing 2024201067_q1.sh]
1. Open the script in any text editor or IDE. Also keep 'access.log' is present in the same working directory.
2. Modify the execute-permission with command '$chmod +x 2024201067_q1.sh'
3. Run the script to format the log entries.


[Ques.02. Summing Power Levels]
This task involves summing up the 'power_levels' from a file named 'power_levels.txt'

[Steps for executing 2024201067_q2.sh]
1. Open the script in any text editor or IDE. Also keep 'power_levels.txt' is present in the same working directory.
2. Modify the execute-permission with command '$chmod +x 2024201067_q2.sh'
3. Run the script to calculate the total-power level.


THANK YOU!

